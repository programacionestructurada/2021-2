#ifndef POLIGONO_H_INCLUDED
#define POLIGONO_H_INCLUDED
#include <iostream>
/**An abstract class example*/
class Poligono {
protected:
 std::string nombre;
public:
 Poligono(std::string name):nombre(name){/**Empty*/}
 virtual float area() = 0;/**pure virtual method*/
};/*end class Poligono*/
#endif // POLIGONO_H_INCLUDED
