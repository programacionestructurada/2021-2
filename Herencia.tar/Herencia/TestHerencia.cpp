#include <iostream>

using namespace std;
#include "PoligonoRegular.h"
#include "Triangulo.h"
#include "Rectangulo.h"
#define TAM 3
#define BASE_T    100
#define ALTURA_T  75
#define BASE_R    100
#define ALTURA_R  75

int main()
{
 Poligono *Pol_Array[TAM];
 cout << "Jerarqu\\'ia de Clases!" << endl;
 Pol_Array[0] = new Triangulo(BASE_T,ALTURA_T);
 Pol_Array[1] = new Rectangulo(BASE_R,ALTURA_R);

 for(unsigned int i=0;i<2;i++){
   printf("%-20s%10.2f",
          &Pol_Array[i].nombre[0],
          Pol_Array[i]->area());
 }
 return 0;
}/*end main()*/
