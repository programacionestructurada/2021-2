#ifndef POLIGONOREGULAR_H_INCLUDED
#define POLIGONOREGULAR_H_INCLUDED
/**Clase provisionalmente abstracta, v\'ease
 * el comentario junto al m\'etodo virtual
 * puro de esta clase.
 */
class PoligonoRegular : public Poligono {
private:
 float apotema;
 float perimetro;
protected:
 float cantidad_d_lados;
 float longitud_d_lado;
public:
 PoligonoRegular(float cdlados,float ldlado)
 :cantidad_d_lados(cdlados),longitud_d_lado(ldlado)
 {/**Empty*/}
 virtual float area() = 0;/**Funci\'on virtual pura, hasta
                             que encuentre la f\'ormula
                             para la apotema en funci\'on
                             de la longitud de un lado del
                             pol\'igono regular.*/
};/*end class PoligonoRegular*/
#endif // POLIGONOREGULAR_H_INCLUDED
